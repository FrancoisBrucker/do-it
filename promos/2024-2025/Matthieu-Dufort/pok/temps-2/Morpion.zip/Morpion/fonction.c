#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"

void affiche(Morpion *tab){
        printf("  A   B   C \n1 %c | %c | %c \n  - - - - -\n",tab->grille[0], tab->grille[1], tab->grille[2]);
        printf("2 %c | %c | %c \n  - - - - -\n",tab->grille[3],tab->grille[4],tab->grille[5]);
        printf("3 %c | %c | %c",tab->grille[6],tab->grille[7],tab->grille[8]);
};

int gagner(Morpion *tab){
    for(int i=0 ; i < 3 ; i ++)
    {
        if( (tab->grille[i + 2*i] == 'X')&& (tab->grille[i + 1 + 2*i] == 'X')&& (tab->grille[i + 2 + 2*i] == 'X'))// Verification des lignes pour x
        {
            return 1 ;
        }
        else if( (tab->grille[i + 2*i] == 'O')&& (tab->grille[i + 1 + 2*i] == 'O')&& (tab->grille[i + 2 + 2*i] == 'O'))// Verification des lignes pour O
        {
            return 2 ;
        }
        else if( (tab->grille[i] == 'O')&& (tab->grille[i + 3] == 'O')&& (tab->grille[i + 6] == 'O'))// Verification des colonnes pour O
        {
            return 2 ;
        }
        else if( (tab->grille[i] == 'X')&& (tab->grille[i + 3] == 'X')&& (tab->grille[i + 6] == 'X'))// Verification des colonnes pour X
        {
            return 1 ;
        }
        else if((tab->grille[4] == 'X')&& ((tab->grille[0] == 'X')&& (tab->grille[8] == 'X'))||((tab->grille[2] == 'X')&& (tab->grille[6] == 'X')))// Verification des diagonnales pour X
        {
            return 1 ;
        }
        else if((tab->grille[4] == 'O')&& ((tab->grille[0] == 'O')&& (tab->grille[8] == 'O'))||((tab->grille[2] == 'O')&& (tab->grille[6] == 'O')))// Verification des diagonnales pour X
        {
            return 2 ;
        }
        else if((tab->grille[0] != ' ') && (tab->grille[1] != ' ') && (tab->grille[2] != ' ') && (tab->grille[3] != ' ') && (tab->grille[4] != ' ') && (tab->grille[5] != ' ') && (tab->grille[6] != ' ') && (tab->grille[7] != ' ') && (tab->grille[8] != ' '))
        {
            return 3 ;
        }
    }
    return 0 ;
     
};


int jouer(Morpion *tab, char jeu, char *position){
    int error = 1 ;
    if((strcmp(position, "A1") == 0) && tab->grille[0] == ' ')
    {
        tab->grille[0] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "B1") == 0) && tab->grille[1] == ' ')
    {
        tab->grille[1] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "C1") == 0) && tab->grille[2] == ' ')
    {
        tab->grille[2] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "A2") == 0) && tab->grille[3] == ' ')
    {
        tab->grille[3] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "B2") == 0) && tab->grille[4] == ' ')
    {
        tab->grille[4] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "C2") == 0) && tab->grille[5] == ' ')
    {
        tab->grille[5] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "A3") == 0) && tab->grille[6] == ' ')
    {
        tab->grille[6] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "B3") == 0) && tab->grille[7] == ' ')
    {
        tab->grille[7] = jeu ;
        error = 0 ;
    }
    else if((strcmp(position, "C3") == 0) && tab->grille[8] == ' ')
    {
        tab->grille[8] = jeu ;
        error = 0 ;
    }
    return error ;
    
};
