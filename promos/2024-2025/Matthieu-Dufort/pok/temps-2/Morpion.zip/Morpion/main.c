#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"

int main(int argc, char *argv[])
{
    Morpion tab= {{' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}};
    int tour =0 ;
    int error = 0 ;
    int result = 0 ;
    char jeu ;
    char position[3];
    printf("Le jeu peut commencer ! \n");
    affiche(&tab);
    while(result == 0)
    {
        if(tour % 2  == 0)
        {
            jeu = 'X';
        }
        else
        {
            jeu = 'O';
        }
        printf("\nC'est au tour de %c, que voulez vous jouer ?", jeu);
        scanf("%2s", &position);
        error = jouer(&tab, jeu, position);
        if(error == 1)
        {
            printf("Attention la case est déjà prise ou votre entrée était invalide, veuillez rejouer !\n");
            tour --;
        }
        affiche(&tab);
        result = gagner(&tab);        
        tour ++;
    }
    if(result == 1)
    {
        printf("\n\nBravo X, vous avez gagné !\n");
    }
    else if (result == 2)
    {
        printf("\n\nBravo O, vous avez gagné !\n");
    }
    else if (result == 3)
    {
        printf("\n\nEgalité !\n");
    }

}