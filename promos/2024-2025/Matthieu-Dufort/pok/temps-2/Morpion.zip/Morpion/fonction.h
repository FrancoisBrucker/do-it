#ifndef FONCTION_H
#define FONCTION_H
#include <stdio.h>



typedef struct Morpion Morpion ;
struct Morpion
{
    char grille[9];
};

void affiche(Morpion *grille);
int gagner(Morpion *grille);
int jouer(Morpion *grille, char jeu, char *position);

#endif