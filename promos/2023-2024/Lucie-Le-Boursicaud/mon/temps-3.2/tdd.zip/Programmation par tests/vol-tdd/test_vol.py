from vol import VolSysteme

def test_ajouter_vol():
    volsysteme=VolSysteme()
    volsysteme.ajouter_vol("Rayanair","Marseille","Lisbonne","16:00","17:20","12/03/2024","RYA2598")
    volsysteme.ajouter_vol("EasyJet","Marseille","Lisbonne","15:10","16:35","12/03/2024","EZS081")
    assert volsysteme.recherche_vol("Marseille","Lisbonne","12/03/2024")==["RYA2598","EZS081"]

def test_réserver_siège():
    volsysteme=VolSysteme()
    volsysteme.ajouter_vol("Rayanair","Marseille","Lisbonne","16:00","17:20","12/03/2024","RYA2598")
    volsysteme.ajouter_vol("EasyJet","Marseille","Lisbonne","15:10","16:35","12/03/2024","EZS081")
    assert volsysteme.réserver_siège("RYA2598", "Economique", "A1", "Lucie Le Boursicaud")==True
    assert ("A1" in volsysteme.vols[0]["sièges"]["Economique"]) == True
    assert volsysteme.obtenir_liste_passager("RYA2598","Economique") == {'A1': 'Lucie Le Boursicaud'}

def test_annuler_réservation():
    volsysteme=VolSysteme()
    volsysteme.ajouter_vol("Rayanair","Marseille","Lisbonne","16:00","17:20","12/03/2024","RYA2598")
    volsysteme.ajouter_vol("EasyJet","Marseille","Lisbonne","15:10","16:35","12/03/2024","EZS081")
    assert volsysteme.réserver_siège("RYA2598","Economique", "A1","Lucie Le Boursicaud")==True
    assert volsysteme.annuler_réservation("RYA2598","Economique", "A1")==True
    assert ("A1" not in volsysteme.vols[0]["sièges"]) == True

def test_définir_tarif():
    volsysteme=VolSysteme()
    volsysteme.ajouter_vol("Rayanair","Marseille","Lisbonne","16:00","17:20","12/03/2024","RYA2598")
    volsysteme.ajouter_vol("EasyJet","Marseille","Lisbonne","15:10","16:35","12/03/2024","EZS081")
    assert volsysteme.définir_tarif("EZS081", "Economique", 105)==True
    for vol in volsysteme.vols:
        if vol["numero"] == "EZS081":
            assert vol["sièges"]["Economique"] == 105

def recherche_vol_avec_tarif():
    volsysteme=VolSysteme()
    volsysteme.ajouter_vol("Rayanair","Marseille","Lisbonne","16:00","17:20","12/03/2024","RYA2598")
    volsysteme.ajouter_vol("EasyJet","Marseille","Lisbonne","15:10","16:35","12/03/2024","EZS081")
    volsysteme.ajouter_vol("AirFrance","Marseille","Lisbonne","14:25","15:50","12/03/2024","AF9271")
    volsysteme.définir_tarif("EZS081", "Economique", 105)==True
    volsysteme.définir_tarif("RYA2598", "Economique", 98)==True
    volsysteme.définir_tarif("AF9271", "Economique", 179)==True
    volsysteme.définir_tarif("AF9271", "Business", 275)==True
    volsysteme.définir_tarif("AF9271", "Premiere", 642)==True
    assert volsysteme.recherche_vol_avec_tarif("Marseille","Lisbonne","12/03/2024")=={"RYA2598" : {"Economique":98,"Business":null,"Premiere":null},"EZS081":{"Economique":105,"Business":null,"Premiere":null},"AF9271":{"Economique":179,"Business":275,"Premiere":642}}