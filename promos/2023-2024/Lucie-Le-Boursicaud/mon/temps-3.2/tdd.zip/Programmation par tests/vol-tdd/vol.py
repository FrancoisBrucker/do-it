class VolSysteme():
    def __init__(self):
        self.vols = []

    def ajouter_vol(self,compagnie, depart, arrivee, heured, heurea, date, numero):
        vol = {"compagnie":compagnie, "depart":depart, "arrivee":arrivee, "heured":heured, "heurea":heurea, "date": date, "numero":numero, "sièges": {"Economique" : {}, "Business":{}, "Premiere":{}}}
        self.vols.append(vol)
    
    def recherche_vol(self,depart,arrivee,date):
        vols_possibles=[]
        for vol in self.vols:
            print(vol)
            if(vol["arrivee"] == arrivee and vol["depart"] == depart and vol["date"] == date):
                vols_possibles.append(vol["numero"])
        return vols_possibles
    
    def réserver_siège(self, numéro_vol,classe, siège, passager):
        for vol in self.vols:
            if vol["numero"] == numéro_vol:
                if classe in vol["sièges"]:
                    if siège in vol["sièges"][classe]:
                        return False
                    vol["sièges"][classe][siège] = passager
                return True
        return False

    def annuler_réservation(self, numéro_vol, classe, siège):
        for vol in self.vols:
            if vol["numero"] == numéro_vol and classe in vol["sièges"] and siège in vol["sièges"][classe]:
                vol["sièges"][classe].pop(siège)
                return True
        return False
    
    def obtenir_liste_passager(self, numero, classe):
        for vol in self.vols:
            if vol["numero"] == numero:
                sièges=vol["sièges"][classe]
                return sièges
        return None
    
    def définir_tarif(self, numero, classe, tarif):
        for vol in self.vols:
            if vol["numero"] == numero:
                classes = vol["sièges"]
                classes[classe] = tarif
                return True 
        return False
    

    def recherche_vol_avec_tarif(self,depart,arrivee,date):
        vols_possibles=[]
        for vol in self.vols:
            print(vol)
            if(vol["arrivee"] == arrivee and vol["depart"] == depart and vol["date"] == date):
                vols_possibles.append({vol["numero"],vol["sièges"]})
        return vols_possibles