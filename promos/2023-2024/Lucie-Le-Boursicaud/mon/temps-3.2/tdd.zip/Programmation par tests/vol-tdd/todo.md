## MY TODO
- [] Pouvoir ajouter un nouveau vol en précisant la compagnie, la ville de départ, la ville d'arrivée, l'heure de départ, l'heure d'arrivée, la date du vol et le numéro de vol
- [] Rechercher des vols disponibles en précisant une ville de départ, une ville d'arrivée et la date du voyage
- [] Pouvoir réserver un vol et obtenir un numéro de réservation
- [] Pouvoir réserver un siège sur le vol à l'aide du numéro de réservation
- [] Pouvoir annuler une réservation à l'aide de son numéro

