from calculatrice import Calculatrice

def test_addition():
    assert Calculatrice.add(1,2)==3

def test_soustraction():
    assert Calculatrice.sub(5,3)==2

def test_multiplication():
    assert Calculatrice.mul(4,5)==20

def test_division():
    assert Calculatrice.div(36,3)==12