class Calculatrice():
    def add(self, other) :
        return self + other
    
    def sub(self, other) :
        return self - other
    
    def mul(self, other) : 
        return self*other
    
    def div(self, other):
        return self/other