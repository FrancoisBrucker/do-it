## MY TODO 1
- [] Pouvoir ajouter deux nombres
- [] Pouvoir soustraire deux nombres
- [] Pouvoir multiplier deux nombres
- [] Pouvoir diviser deux nombres