# My TO DO LIST ETAPE 1
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] $5*2 = $10
  
# My TO DO LIST ETAPE 2
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [-] $5*2 = $10
- [] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)

# My TO DO LIST ETAPE 3 
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5*2 = $10
- [] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [-] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)

# My TO DO LIST ETAPE 4
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5*2 = $10
- [] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [x] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)
- [-] ==

# My TO DO LIST ETAPE 5
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5*2 = $10
- [] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [x] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)
- [x] ==
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [-] __mul__

# My TO DO LIST ETAPE 6
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5*2 = $10
- [-] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [x] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)
- [x] ==
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] __mul__

# My TO DO LIST ETAPE 7
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5*2 = $10
- [x] utiliser montant ? Le rendre privé (le cacher à l'utilisateur (ici les tests))
- [x] cinq == $10 (ce n'est pas super car nos $5 initiaux valent maintenant $10) => rendre Dollar non modifiable
- [] gestion des arrondis (lorsque les montants seront des réels)
- [x] ==
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] __mul__


# My TO DO LIST ETAPE 8
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [-] 5 CHF * 2 == 10 CHF
- 
# My TO DO LIST ETAPE 9
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] 5 CHF * 2 == 10 CHF
- [ ] duplication Franc/dollar
- [x] même == (code indentique dans 2 classes différentes)
- [ ] * presque identitque
- [-] compare Franc et Dollar

# My TO DO LIST ETAPE 10
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] 5 CHF * 2 == 10 CHF
- [-] duplication Franc/dollar
- [x] même == (code indentique dans 2 classes différentes)
- [ ] * presque identitque
- [x] compare Franc et Dollar
- [ ] utilisation de devises plutôt que de classes
- [ ] supprimer les tests de Franc ? 

# My TO DO LIST ETAPE 11
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] 5 CHF * 2 == 10 CHF
- [x] duplication Franc/dollar
- [x] même == (code indentique dans 2 classes différentes)
- [ ] * presque identitque
- [x] compare Franc et Dollar
- [-] utilisation de devises plutôt que de classes
- [ ] supprimer les tests de Franc ? 

# My TO DO LIST ETAPE 12
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] 5 CHF * 2 == 10 CHF
- [x] duplication Franc/dollar
- [x] même == (code indentique dans 2 classes différentes)
- [-] * presque identitque
- [x] compare Franc et Dollar
- [x] utilisation de devises plutôt que de classes
- [ ] supprimer les tests de Franc ? 

# My TO DO LIST ETAPE 13
- [] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
- [x] 5 CHF * 2 == 10 CHF
- [x] duplication Franc/dollar
- [x] même == (code indentique dans 2 classes différentes)
- [x] * presque identitque
- [x] compare Franc et Dollar
- [x] utilisation de devises plutôt que de classes
- [x] supprimer les tests de Franc ? 

# My TO DO LIST ETAPE 14
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [-] $5 + $2 = $7
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar

# My TO DO LIST ETAPE 15
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [x] $5 + $2 = $7
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar

# My TO DO LIST ETAPE 16
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [ ] $5 + $2 doit être égal à $7
- [x] $5 + $2 = quelque chose qui correspond à $7
- [ ] Banque.conversion(Monnaie)
- [ ] Somme.conversion(devise) doit vraiment faire des conversions
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar
  
# My TO DO LIST ETAPE 17
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [ ] $5 + $2 doit être égal à $7
- [x] $5 + $2 = quelque chose qui correspond à $7
- [-] Banque.conversion(Monnaie)
- [ ] Somme.conversion(devise) doit vraiment faire des conversions
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar

# My TO DO LIST ETAPE 18
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [ ] $5 + $2 doit être égal à $7
- [x] $5 + $2 = quelque chose qui correspond à $7
- [x] Banque.conversion(Monnaie)
- [ ] Somme.conversion(devise) doit vraiment faire des conversions
- [-] Monnaie.conversion(devise) doit vraiment faire des conversions
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar

# My TO DO LIST ETAPE 19
- [ ] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [ ] $5 + $2 doit être égal à $7
- [x] $5 + $2 = quelque chose qui correspond à $7
- [x] Banque.conversion(Monnaie)
- [-] Somme.conversion(devise) doit vraiment faire des conversions
- [x] Monnaie.conversion(devise) doit vraiment faire des conversions
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar

# My TO DO LIST ETAPE 20
- [x] $5 + 2.5CHF = $10 si le taux de change est 1.5
- [ ] $5 + $2 doit être égal à $7
- [x] $5 + $2 = quelque chose qui correspond à $7
- [x] Banque.conversion(Monnaie)
- [x] Somme.conversion(devise) doit vraiment faire des conversions
- [x] Monnaie.conversion(devise) doit vraiment faire des conversions
- [ ] gestion des arrondis (lorsque les montants seront des réels)
- [ ] == None
- [ ] == autre chose qu'un Dollar






