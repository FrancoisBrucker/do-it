class Bibliotheque() : 
    def __init__(self):
        self.livres = []

    def add_book(self, titre, auteur, annee):
        livre = {"titre" : titre, "auteur": auteur, "année" : annee, "disponible" : True}
        self.livres.append(livre)

    def livre_existe(self, titre):
        for livre in self.livres : 
            if livre["titre"] == titre:
                return True
        return False
    
    def recherche_livre(self, titre):
        for livre in self.livres :
            if livre["titre"] == titre:
                return [livre["titre"],livre["auteur"],livre["année"],livre["disponible"]]
            
    def recherche_livres_par_auteur(self, auteur):
        listes_des_livres=[]
        for livre in self.livres : 
            if livre["auteur"]==auteur:
                listes_des_livres.append(livre["titre"])
        return listes_des_livres

    def emprunt_livre(self, titre):
        for livre in self.livres :
            if livre["titre"] == titre and livre["disponible"]:
                livre["disponible"]=False
                return True
        return False

    def retour_livre(self, titre):
        for livre in self.livres :
            if livre["titre"] == titre:
                livre["disponible"]=True
        pass
    
    def livre_disponible(self, titre):
        for livre in self.livres :
            if livre["titre"] == titre: 
                return livre["disponible"]
        return False