from bibliotheque import Bibliotheque

def test_ajout_livre():
    bibliotheque= Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    assert bibliotheque.livre_existe("L'Ecume des jours")

def test_recherche_livre():
    bibliotheque= Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    assert bibliotheque.recherche_livre("L'Ecume des jours")==["L'Ecume des jours","Boris Vian",1947,True]

def test_recherche_livres_par_auteur():
    bibliotheque= Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    bibliotheque.add_book("L'Arrache-coeur","Boris Vian",1953)
    bibliotheque.add_book("Les Misérables","Victor Hugo",1862)
    assert bibliotheque.recherche_livres_par_auteur("Boris Vian")==["L'Ecume des jours","L'Arrache-coeur"]
    assert bibliotheque.recherche_livres_par_auteur("Victor Hugo")==["Les Misérables"]

def test_emprunt_livre():
    bibliotheque=Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    bibliotheque.add_book("L'Arrache-coeur","Boris Vian",1953)
    bibliotheque.add_book("Les Misérables","Victor Hugo",1862)
    assert bibliotheque.emprunt_livre("L'Arrache-coeur")==True
    assert bibliotheque.emprunt_livre("L'Arrache-coeur")==False
    assert bibliotheque.emprunt_livre("L'Ecume des jours")==True

def test_est_diponible():
    bibliotheque=Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    bibliotheque.add_book("L'Arrache-coeur","Boris Vian",1953)
    bibliotheque.emprunt_livre("L'Ecume des jours")
    assert bibliotheque.livre_disponible("L'Ecume des jours")==False
    assert bibliotheque.livre_disponible("L'Arrache-coeur")==True

def test_retour_livre():
    bibliotheque=Bibliotheque()
    bibliotheque.add_book("L'Ecume des jours","Boris Vian",1947)
    bibliotheque.add_book("L'Arrache-coeur","Boris Vian",1953)
    bibliotheque.add_book("Les Misérables","Victor Hugo",1862)
    bibliotheque.emprunt_livre("L'Arrache-coeur")
    bibliotheque.emprunt_livre("L'Ecume des jours")
    bibliotheque.retour_livre("L'Arrache-coeur")
    assert bibliotheque.livre_disponible("L'Arrache-coeur")==True
    assert bibliotheque.livre_disponible("L'Ecume des jours")==False