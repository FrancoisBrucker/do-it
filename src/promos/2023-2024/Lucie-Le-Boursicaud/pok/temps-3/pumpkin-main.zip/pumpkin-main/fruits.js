export const FRUITS = [
  {
    label: "radish",
    radius: 40 / 2,
    color: "#F20306",
    points: 10
  },
  {
    label: "garlic",
    radius: 50 / 2,
    color: "#FF624C",
    points: 15
  },
  {
    label: "onionw",
    radius: 72 / 2,
    color: "#A969FF",
    points: 20
  },
  {
    label: "lemon",
    radius: 85 / 2,
    color: "#FFAF02",
    points: 30
  },
  {
    label: "orange",
    radius: 106 / 2,
    color: "#FC8611",
    points: 45
  },
  {
    label: "tomato",
    radius: 140 / 2,
    color: "#F41615",
    points: 65
  },
  {
    label: "onion",
    radius: 160 / 2,
    color: "#FDF176",
    points: 90
  },
  {
    label: "paprika",
    radius: 196 / 2,
    color: "#FEB6AC",
    points: 130
  },
  {
    label: "eggplant",
    radius: 220 / 2,
    color: "#F7E608",
    points: 200
  },
  {
    label: "artichoke",
    radius: 270 / 2,
    color: "#89CE13",
    points: 300
  },
  {
    label: "pumpkin",
    radius: 300 / 2,
    color: "#26AA1E",
    points: 450
  },
];

