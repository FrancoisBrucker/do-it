import {Engine, Render, Runner, Bodies, World, Body, Sleeping, Events} from 'matter-js';

import { FRUITS } from './fruits';

const engine = Engine.create();
const render = Render.create({
    engine,
    element: document.body,
    options: {
        wireframes:false,
        background: "#E3F0FE",
        width: 620,
        height: 850,
    },
});

const world = engine.world;

const sol = Bodies.rectangle(310,820,620,60,{
    isStatic:true,
    render: {
        fillStyle: "#D2B48C",
    },
    label: "sol",
});

const murgauche = Bodies.rectangle(15,395,30,790,{
    isStatic:true,
    render: {
        fillStyle: "#D2B48C",
    },
    label: "murgauche",
});

const murdroite = Bodies.rectangle(605,395,30,790,{
    isStatic:true,
    render: {
        fillStyle: "#D2B48C",
    },
    label: "murdroite",
});

const lignehaut = Bodies.rectangle(310,150,620,2, {
    isStatic: true,
    isSensor: true,
    render: {fillStyle: "#D2B48C"},
    label: "ligne",
})


// const box = Bodies.circle(100,100,20,{
//     restitution: 0.6,
// });

World.add(world, [sol,murgauche,murdroite,lignehaut]);

Render.run(render);
Runner.run(engine);

let fruitActuel =null;
let interval = null;
let disableAction = false;
let score = 0;

function updateScore(points) {
    score += points;
    document.getElementById('score').innerText = `Score: ${score}`;
}


function ajouterFruit(){
    const randomFruit = getRandomFruit();

    const body = Bodies.circle(300, 50,randomFruit.radius, {
        label : randomFruit.label,
        isSleeping: true,
        render : {
            fillStyle: randomFruit.color,
            sprite: { texture: `/${randomFruit.label}.png` },
        },
        restitution: 0.2,
    });

    fruitActuel = body;

    World.add(world,body);
};



function getRandomFruit(){
    const randomIndex = Math.floor(Math.random() * 5);
    const fruit = FRUITS[randomIndex];

    return fruit;
};


window.onkeydown = (event) => {
    if(disableAction) return;
    switch (event.code) {
        case "ArrowDown":
            if(interval) return ; 
            interval = setInterval(() => {
                if(fruitActuel.position.x - 20 > 30)
            Body.setPosition(fruitActuel, {
                x: fruitActuel.position.x - 1, 
                y: fruitActuel.position.y,
            });
            }, 5);
            break;
        case "ArrowRight":
            if(interval) return ; 
            interval = setInterval(() => {
                if(fruitActuel.position.x + 20 < 590)
            Body.setPosition(fruitActuel, {
                x: fruitActuel.position.x + 1, 
                y: fruitActuel.position.y,
            });
            }, 5);
            break;
        case "Space":
            disableAction=true;
            const indexF = FRUITS.findIndex((fruit)=> fruit.label==fruitActuel.label);
            const monFruit = FRUITS[indexF] ; 
            Sleeping.set(fruitActuel, false);
            setTimeout(() => {
                ajouterFruit();
                disableAction = false;
            },1000);
            updateScore(monFruit.points);
    }
};

window.onkeyup = (event) => {
    switch (event.code) {
        case "ArrowDown":
        case "ArrowRight":
            clearInterval(interval);
            interval = null;
    }
};

Events.on(engine,"collisionStart",(event)=>{
    event.pairs.forEach(collision => {
        if(collision.bodyA.label == collision.bodyB.label){
            World.remove(world, [collision.bodyA, collision.bodyB]);

            const index = FRUITS.findIndex((fruit )=> fruit.label==collision.bodyA.label);

            if(index == FRUITS.length - 1) return;
            
            const newfruit = FRUITS[index + 1];
            const body = Bodies.circle(
                collision.collision.supports[0].x,
                collision.collision.supports[0].y,
                newfruit.radius,
                {render: {
                    fillStyle: newfruit.color,
                    sprite: { texture: `/${newfruit.label}.png` },
                },
            label : newfruit.label,
        });
        updateScore(newfruit.points);
        World.add(world, body);

        }
        if((collision.bodyA.label === "ligne" || collision.bodyB.label === "ligne")&&!disableAction){
            alert("Game over");
            score=0;
          } 
    })
});

document.getElementById('newGameButton').addEventListener('click', () => {
    score = 0;
    updateScore(score);
    world.bodies.filter(body => body.label !== "sol" && body.label !== "ligne" && body.label !== "murgauche"&& body.label !== "murdroite").forEach(body => {
        World.remove(world, body);
    });
    ajouterFruit();
 } );


ajouterFruit();
