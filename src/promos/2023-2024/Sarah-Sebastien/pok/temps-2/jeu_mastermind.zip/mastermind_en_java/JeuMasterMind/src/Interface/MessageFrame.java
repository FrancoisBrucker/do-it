package Interface;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

public class MessageFrame extends JFrame{
    final private Font mainFont = new Font ("Poppins", Font.BOLD, 25);
    final private Font secondFont = new Font ("Poppins",Font.CENTER_BASELINE, 19);
    private List<Color> secretCode;

    public MessageFrame (List<Color> secretCode){
        //permet de récupérer le code secret du MainFrame
        this.secretCode=secretCode;
    }

    public void paint(Graphics g) {
        super.paint(g);

        //creation du rectangle de fond
        g.setColor (Color.WHITE);
        g.fillRect(100,320,480,130);
        
        //creation des icones du code secret
        for (int i = 1; i <= 4; i += 1) {
            g.setColor(secretCode.get(i-1));
            g.fillOval(60+100*i,350,60,60);
        }}

    public void displayMessage(boolean IsWin, List<Color> secretCode){
        //initialisation des text
        JLabel messageLabel = new JLabel ("");
        messageLabel.setFont(mainFont);
        messageLabel.setHorizontalAlignment(JLabel.CENTER);
        JLabel codeLabel = new JLabel ("Le code secret était:");
        codeLabel.setFont(secondFont);
        codeLabel.setHorizontalAlignment(JLabel.CENTER);

        //création des panels
        JPanel textPanel= new JPanel ();
        textPanel.setLayout (new GridLayout (4, 1, 5, 5));
        textPanel.add(messageLabel);
        textPanel.add(codeLabel);
        textPanel.setOpaque(false);

        JButton btnRecommencer = new JButton ("Recommencer");
        btnRecommencer.setFont(mainFont);
        btnRecommencer.addActionListener (new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                MainFrame.main(null);
            }
        });

        JPanel buttonPanel = new JPanel ();
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnRecommencer);

        //creation Panel principal
        JPanel messagePanel= new JPanel ();
        messagePanel.setLayout(new BorderLayout());
        messagePanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        messagePanel.add(textPanel,BorderLayout.CENTER);
        messagePanel.add(buttonPanel,BorderLayout.SOUTH);


        if (IsWin == true){
            messagePanel.setBackground(new Color(178, 255, 106));
            messageLabel.setText("Vous avez gagné ! 😀");
        }
        else {
            messagePanel.setBackground(new Color(240, 89, 89));
            messageLabel.setText("Vous avez perdu... 😢");
        }
        add(messagePanel);

        setTitle("End");
        setSize(700,700);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void go (boolean IsWin,List<Color> secretCode){
        MessageFrame my2Frame = new MessageFrame(secretCode);
        my2Frame.displayMessage(IsWin,secretCode);
        }
}