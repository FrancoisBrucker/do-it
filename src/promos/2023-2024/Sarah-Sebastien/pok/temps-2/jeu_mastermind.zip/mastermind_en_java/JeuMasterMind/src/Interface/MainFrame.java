package Interface;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.*;


public class MainFrame extends JFrame{
    
    final private Font mainFont = new Font ("Poppins", Font.BOLD, 18);
    List<Color> colorAvailable = Arrays.asList(Color.RED,Color.BLUE,Color.CYAN,Color.GREEN,Color.YELLOW,Color.MAGENTA);
    //liste des choix de l'utilisateur à chaque tentative
    List<Color> Choices = Arrays.asList(Color.LIGHT_GRAY,Color.LIGHT_GRAY,Color.LIGHT_GRAY,Color.LIGHT_GRAY);
    //variables relatives à la position des zones de dessin
    private int posXCercleL = 60;
    private int posYCercleL = 65;
    private int posXCercleR = 40;
    private int posYCercleR = 65;

    //nombre de tentatives autorisées
    private int maxTries = 7;
    
    //initialisation d'une grille vide de 7 tentatives
    Color[][] choicesGrid = initializeGrid (maxTries,4,Color.BLACK);
    //initialisation des indices pour les 7 tentatives
    Color[][] clueGrid = initializeGrid (maxTries,4,new Color (30,30,30));;
    
    //génération d'un code secret pour la partie
    List<Color> secretCode = generateCode();

    //boolean permettant de gérer la fin de la partie
    boolean isGameFinished = false;

    
    public List<Color> getSecretCode() {
        //méthode permettant de faire la connexion avec le frame d'affichage du message final
        return secretCode;
    }

    private List<Color> generateCode(){
        Random random = new Random();
        List<Color> secretCode = new ArrayList<>();

        // Génération de 4 nombres aléatoires entre 1 et 6 (inclus)
        for (int i = 0; i < 4; i++) {
            int randomNumber = random.nextInt(6);
            if (secretCode.contains(colorAvailable.get(randomNumber))){
                do {
                randomNumber = random.nextInt(6);
                } while (secretCode.contains(colorAvailable.get(randomNumber)));
                }

            secretCode.add(colorAvailable.get(randomNumber));
        }
        System.out.println(secretCode);
        return secretCode;
    }

    public Color[][] initializeGrid (int rows, int columns, Color color){
        Color[][] tableau = new Color[rows][columns];
        for(int i = 0; i < tableau.length; i++){
            for(int j = 0; j < tableau[i].length; j++){
                tableau[i][j] = color;
    }}
        return tableau;}

    private void emptyChoicesList(List<Color> list){
        for (int i=0; i < list.size(); i++){
            list.set(i,Color.LIGHT_GRAY);
        }
    }

    public void paint(Graphics g) {
            
        super.paint(g);
        //creation du rectangle de fond
        g.setColor (new Color(91, 91, 91));
        g.fillRect(40,40,580,480);
  
        //grilles de colonnes 
        for (int i = 0; i < (choicesGrid.length); i += 1) {
            for (int j = 0; j < (choicesGrid[i].length); j += 1) {
               g.setColor(choicesGrid[i][j]);
               g.fillOval((j+1)*posXCercleL, (i+1)*posYCercleL,44,44);
        }}

        //lignes choix en cours
        for (int i = 1; i <= 4; i += 1) {
            g.setColor(Choices.get(i-1));
            g.fillOval(i*posXCercleL,550,46,46);
        }

        //creation des icones d'indications des des réponses
        for (int i = 0; i < (clueGrid.length); i += 1) {
            for (int j = 0; j < (clueGrid[i].length); j += 1) {
                g.setColor(clueGrid[i][j]);
                g.fillOval(380 + (j+1)*posXCercleR, 10 + (i+1)*posYCercleR,30,30);
        }}}

        public void changeColor() {
            //permet d'appeler à nouveau la méthode paint pour redessiner les formes
            repaint();
        }
    
    public void initialize(){

        //Panel boutons "valider" et "effacer"
        JPanel ButtonPanel = new JPanel ();
        ButtonPanel.setLayout(null);

        JButton btnValider = new JButton ("Valider");
        btnValider.setFont(mainFont);
        btnValider.setBounds(500,510,100,50);
        btnValider.addActionListener(e -> validateChoices(maxTries));

        JButton btnEffacer = new JButton ("Effacer");
        btnEffacer.setFont(mainFont);
        btnEffacer.setBounds(350,510,100,50);
        btnEffacer.addActionListener (new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //remet à "zéro" (en blanc) le contenu de la liste du choix de l'utilisateur
                emptyChoicesList(Choices);
                changeColor();
            }
        });

        ButtonPanel.add(btnValider);
        ButtonPanel.add(btnEffacer);
        ButtonPanel.setOpaque(false);


        // Panneau choix couleurs
        JPanel colorPanel = new JPanel ();
        colorPanel.setLayout (new GridLayout (1, 6, 20, 10));
        colorPanel.setSize(700,100);
        colorPanel.setOpaque(false);

        //Ajout des boutons des couleurs
        JButton btnRed = new JButton();
        btnRed.setBackground(Color.RED); 
        btnRed.addActionListener(e -> updateChoice(Color.RED));
        btnRed.setPreferredSize(new Dimension(this.WIDTH, 50));

        JButton btnBlue = new JButton();
        btnBlue.setBackground(Color.BLUE);
        btnBlue.addActionListener(e -> updateChoice(Color.BLUE));

        JButton btnCyan = new JButton();
        btnCyan.setBackground(Color.CYAN);
        btnCyan.addActionListener(e -> updateChoice(Color.CYAN));

        JButton btnYellow = new JButton();
        btnYellow.setBackground(Color.YELLOW); 
        btnYellow.addActionListener(e -> updateChoice(Color.YELLOW));

        JButton btnGreen = new JButton();
        btnGreen.setBackground(Color.GREEN); 
        btnGreen.addActionListener(e -> updateChoice(Color.GREEN));


        JButton btnPink = new JButton();
        btnPink.setBackground(Color.MAGENTA);
        btnPink.addActionListener(e -> updateChoice(Color.MAGENTA));
        
        colorPanel.add(btnRed);
        colorPanel.add(btnBlue);
        colorPanel.add(btnCyan);
        colorPanel.add(btnYellow);
        colorPanel.add(btnGreen);
        colorPanel.add(btnPink);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(30, 30, 30));
        //On ajoute le form panel au main Panel dans la partie "sud"
        mainPanel.add(colorPanel, BorderLayout.SOUTH);
        //On ajoute des marges
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        mainPanel.add(ButtonPanel,BorderLayout.CENTER);

        add(mainPanel);

        setTitle("Mastermind");
        setSize(700,700);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        
    }

    private void updateChoice(Color color) {
        //méthode permettant de mettre à jour les couleurs choisies par l'utilisateur 
        for (int i = 0; i <= Choices.size(); i++) {
            if (Choices.get(i)==Color.LIGHT_GRAY) {
            // Changer la valeur de l'élément vide à la valeur du bouton appuyé
                Choices.set(i, color);
                System.out.println(color);
                changeColor();
                break;
    }}}

    private boolean isCompleted (List<Color> listColor){
        //méthode permettant de déterminer si l'utilisateur a bien sélectionné 4 couleurs avant de valider
        for (int i = 0; i< listColor.size(); i++){
            if (listColor.get(i) == Color.LIGHT_GRAY){
                return false;
            }}
        return true;
    }

    private void validateChoices (int index) {

        if (isCompleted(Choices)){
            for(int j = 0; j < choicesGrid[index-1].length; j ++ ){
                choicesGrid[index-1][j] = Choices.get(j);
                }
        //on actualise la grid
        changeColor();
        //on indique les indices de la tentative jouée
        indicateClues(index);
        //on initialise le zone de choix de couleurs de l'utilisateur
        emptyChoicesList(Choices);
        maxTries--;
        //test si la partie est finie
        MessageBox(maxTries, isGameFinished);
        }}

    private void indicateClues(int index){
        //si une couleur est bien placée : goodPlace+1
        //si une couleur est bonne et bien placée : goodColor+1
        int goodColor=0;
        int goodPlace=0;
        for(int j = 0; j < choicesGrid[index-1].length; j ++ ){
            if (choicesGrid[index-1][j] == secretCode.get(j)){
                goodPlace+=1;}
            else if (secretCode.contains(choicesGrid[index-1][j])){
                goodColor+=1;
            }}

        for (int k = 0; k < goodPlace; k++){
            clueGrid[index-1][k]=(new Color (141, 1, 1));}
        for (int l = goodPlace; l<goodColor+goodPlace; l++){
            clueGrid[index-1][l]=Color.WHITE;}

        //si toutes les couleurs sont bonnes et bien placées le jeu est terminé
        if (goodPlace == 4){
            isGameFinished=true;
        }
    }

    private void MessageBox (int ESSAI, boolean IsGameFinished){
        //méthode qui permet d'affiche le message de fin de partie en fonction de la réussite de l'utilisateur
        if (ESSAI == 0 & IsGameFinished != true){
           MessageFrame.go(false,secretCode);
        }
        if (IsGameFinished == true){
            MessageFrame.go(true,secretCode);
        }
    }

        
  //Création de la méthode principale pour executer le panneau principal
    public static void main (String[] args){
        MainFrame myFrame = new MainFrame();
        myFrame.initialize();
        }
}
    

  
