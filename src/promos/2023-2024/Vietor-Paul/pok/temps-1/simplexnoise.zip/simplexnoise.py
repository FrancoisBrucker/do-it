﻿from math import sqrt, floor, sin, cos, pi
import matplotlib.pyplot as plt
import numpy as np

r = .55
n = 289
F = (sqrt(3) - 1) / 2
G = (3 - sqrt(3)) / 6

a = 22695477
c = 1

freq = 0.01
pers = 0.4

rng = np.random.default_rng()

# gradients2D = [(cos(2 * pi * i / n), sin(2 * pi * i / n)) for i in range(n)]
gradients2D = np.array([(cos(2 * pi * i / n), sin(2 * pi * i / n)) for i in range(n)])
# gradients2D = np.array([[1, 1], [1, -1], [-1, -1], [-1, 1]])


def shuffle(x):
    return ((a * x + c) // 65536) % n


def dot(v1, v2):
    return v1[0] * v2[0] + v1[1] * v2[1]


def skew(x, y):
    return (x + (x + y) * F, y + (x + y) * F)


def unskew(x, y):
    return (x - (x + y) * G, y - (x + y) * G)


def simplex_noise_2D(x, y):
    # skew coordinates
    x2, y2 = skew(x, y)

    # Detemine the simplex in which the skewed point lies
    x2i, y2i = x2 % 1, y2 % 1
    v1 = (floor(x2), floor(y2))
    v2 = (floor(x2) + 1, floor(y2)) if x2i > y2i else (floor(x2), floor(y2) + 1)
    v3 = (floor(x2) + 1, floor(y2) + 1)

    # Unskew the simplex's coordinates
    u1 = unskew(*v1)
    u2 = unskew(*v2)
    u3 = unskew(*v3)

    # Get a pseudo-random gradient direction for each vertex of the simplex
    grad1 = gradients2D[hash(v1) % n]
    grad2 = gradients2D[hash(v2) % n]
    grad3 = gradients2D[hash(v3) % n]

    d1 = u1[0] - x, u1[1] - y
    d2 = u2[0] - x, u2[1] - y
    d3 = u3[0] - x, u3[1] - y

    # Calculate noise value
    m1 = max(0, r - dot(d1, d1))**4 * dot(d1, grad1)
    m2 = max(0, r - dot(d2, d2))**4 * dot(d2, grad2)
    m3 = max(0, r - dot(d3, d3))**4 * dot(d3, grad3)
    return m1 + m2 + m3


def simplex_noise_2D_numpy(coords):
    h, w, _ = coords.shape
    s = coords + F * coords.sum(axis=2).reshape(h, w, 1)  # Skew the input coordinates
    v1 = np.floor(s)
    s_i = s - v1  # Coordinates of skewed input point within the skewed square
    v2 = np.zeros(coords.shape)
    v2[:, :, 0] = s_i[:, :, 0] > s_i[:, :, 1]
    v2[:, :, 1] = s_i[:, :, 0] <= s_i[:, :, 1]
    v2 += v1
    v3 = v1 + np.ones(v1.shape)

    # Unskew
    v1 = v1 - G * v1.sum(axis=2).reshape(h, w, 1)
    v2 = v2 - G * v2.sum(axis=2).reshape(h, w, 1)
    v3 = v3 - G * v3.sum(axis=2).reshape(h, w, 1)

    # TODO: Get random directions for the gradient at each vertex

    dir1 = gradients2D[shuffle(np.add(shuffle(v1[:, :, 0]), shuffle(shuffle(v1[:, :, 1]))).astype(int))]
    dir2 = gradients2D[shuffle(np.add(shuffle(v2[:, :, 0]), shuffle(shuffle(v2[:, :, 1]))).astype(int))]
    dir3 = gradients2D[shuffle(np.add(shuffle(v3[:, :, 0]), shuffle(shuffle(v3[:, :, 1]))).astype(int))]

    d1 = coords - v1
    d2 = coords - v2
    d3 = coords - v3

    m1 = np.fmax(0, r - (d1 * d1).sum(axis=2))**4
    m2 = np.fmax(0, r - (d2 * d2).sum(axis=2))**4
    m3 = np.fmax(0, r - (d3 * d3).sum(axis=2))**4

    grad1 = (d1 * dir1).sum(axis=2)
    grad2 = (d2 * dir2).sum(axis=2)
    grad3 = (d3 * dir3).sum(axis=2)

    return m1 * grad1 + m2 * grad2 + m3 * grad3


# values = np.array([[(simplex_noise_2D(i / 100, j / 100)) for j in range(-1000, 1001)] for i in range(-1000, 1001)])
#
# rng.shuffle(gradients2D)
# print(gradients2D)
#
# values += 0.5 * np.array([[(simplex_noise_2D(i / 50, j / 50)) for j in range(-1000, 1001)] for i in range(-1000, 1001)])
#
# rng.shuffle(gradients2D)
# print(gradients2D)
#
# values += 0.25 * np.array([[(simplex_noise_2D(i / 25, j / 25)) for j in range(-1000, 1001)] for i in range(-1000, 1001)])

coords = np.array([[(i, j) for j in range(-1000, 1001)] for i in range(-1000, 1001)])
values = np.zeros((2001, 2001))

# for i in range(4):
#     rng.shuffle(gradients2D)
values = simplex_noise_2D_numpy(coords * freq)

plt.imshow(values, interpolation="bicubic")
plt.show()
