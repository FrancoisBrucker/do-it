from pony import orm
from DataModel import Tool, Employee, Supplier, Order, Skill, Client, Material, ConstructionSite, db
 
db.bind('sqlite', 'database.sqlite', create_db=True)
orm.sql_debug(True)
db.generate_mapping(create_tables=True)

with orm.db_session:
    Supplier1 = Supplier(created_at='4/10/2024', name='fourni', type='Bois', phone_number='020515155', email='bla@ble.com')
    Skill1 = Skill(name='Conducteur', description="poids lourd", created_at='14/10/2024')
    Tool1 = Tool(name='Camion', type="Vehicule", acquisition_date="14/10/2024", status='Neuf', created_at="14/10/2024", skill=Skill1)
    Material1 = Material(name="Béton", type="construction lourde", price=10.20, description="bla", created_at="14/10/2024", skill=Skill1)
    Employee1 = Employee(first_name="Seb", last_name='Pat', role="Chef de chantier", start_date='14/10/2024', created_at='14/10/2024', skill=Skill1, active=True)
    Order1 = Order(created_at='14/10/2024', price=1250, currency='euro', supplier=Supplier1, order_number=10)
    
    Order1.materials.add(Material1)
    Order1.tools.add(Tool1)
    
    Client1 = Client(created_at='14/10/2024', first_name='Patrick', last_name="Oudi", birth_date='14/12/1976', type='GC', email='blabla@gmail.com', phone_number='045161526', address='Rue Sainte, 13001, Marseille')
    
    ConstructionSite1 = ConstructionSite(
        name="Maison4", 
        address='Rue des patates', 
        type="Maison", 
        comment='Réparation cuisine', 
        created_at="14/10/2024", 
        status="En cours"
    )

    ConstructionSite1.clients.add(Client1)
    ConstructionSite1.tools.add(Tool1)
    ConstructionSite1.employees.add(Employee1)
    
    db.commit() 
