from pony import orm

db = orm.Database()

class Skill(db.Entity):
    skill_id = orm.PrimaryKey(int, auto=True)
    name = orm.Required(str)
    description = orm.Required(str)
    created_at = orm.Required(str)
    tools = orm.Set("Tool")
    materials = orm.Set("Material")
    employees = orm.Set("Employee")

class Client(db.Entity):
    client_id = orm.PrimaryKey(int, auto=True)
    created_at = orm.Required(str)
    first_name = orm.Required(str)
    last_name = orm.Required(str)
    birth_date = orm.Required(str)
    type = orm.Required(str)
    email = orm.Required(str)
    phone_number = orm.Required(str)
    address = orm.Required(str)
    construction_sites = orm.Set("ConstructionSite")

class Supplier(db.Entity):
    supplier_id = orm.PrimaryKey(int, auto=True)
    created_at = orm.Required(str)
    name = orm.Required(str)
    type = orm.Required(str)
    phone_number = orm.Required(str)
    email = orm.Required(str)
    orders = orm.Set("Order")

class Tool(db.Entity):
    tool_id = orm.PrimaryKey(int, auto=True)
    name = orm.Required(str)
    type = orm.Required(str)
    acquisition_date = orm.Required(str)
    status = orm.Required(str)
    created_at = orm.Required(str)
    skill = orm.Required(Skill)
    construction_sites = orm.Set("ConstructionSite")
    orders = orm.Set("Order")

class Employee(db.Entity):
    employee_id = orm.PrimaryKey(int, auto=True)
    first_name = orm.Required(str)
    last_name = orm.Required(str)
    role = orm.Required(str)
    start_date = orm.Required(str)
    created_at = orm.Required(str)
    active = orm.Required(bool)
    skill = orm.Required(Skill)
    construction_sites = orm.Set("ConstructionSite")

class Material(db.Entity):
    material_id = orm.PrimaryKey(int, auto=True)
    name = orm.Required(str)
    type = orm.Required(str)
    price = orm.Required(float)
    description = orm.Required(str)
    created_at = orm.Required(str)
    skill = orm.Required(Skill)
    orders = orm.Set("Order")

class Order(db.Entity):
    order_id = orm.PrimaryKey(int, auto=True)
    created_at = orm.Required(str)
    price = orm.Required(float)
    currency = orm.Required(str)
    supplier = orm.Required(Supplier)
    order_number = orm.Required(int)
    materials = orm.Set(Material)
    tools = orm.Set(Tool)

class ConstructionSite(db.Entity):
    construction_site_id = orm.PrimaryKey(int, auto=True)
    name = orm.Required(str)
    address = orm.Required(str)
    type = orm.Required(str)
    comment = orm.Required(str)
    created_at = orm.Required(str)  
    status = orm.Required(str)
    clients = orm.Set(Client)
    tools = orm.Set(Tool)
    employees = orm.Set(Employee)
