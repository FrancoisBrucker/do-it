from pony import orm
from DataModel import db, Client

db.bind('sqlite', 'database.sqlite', create_db=True)
db.generate_mapping()

with orm.db_session:
    client = Client.get(first_name='Patrick', last_name='Oudi')

    if client:
        print(f"{client.first_name} {client.last_name}, Email: {client.email}")
    else:
        print("Le client n'existe pas")

