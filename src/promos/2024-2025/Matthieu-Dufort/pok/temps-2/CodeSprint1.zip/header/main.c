// Premier exercice : prise en main du "main"

/*#include <stdio.h> //Directive de préprocesseur (permet d'inclure des bibliothèques)
#include <stdlib.h>

int main() //fonction
{
    printf("Hello world!\n"); // instructions de la fonction (fini par un ; obligatoirement)
                            // /n permet un retour à la ligne dans le terminal pour afficher plus proprement
    return 0; // programme renvoie tjrs une valeur, 0 signifit qu'il n'y a pas de soucis
} */

// 2ème exercice : Variable

/*#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char *argv[])
{
  int nombreDeVies;
  nombreDeVies = 5;
  printf("il vous reste %d vie", nombreDeVies);
       
  return 0;
}
*/
// 3ème exercice : demander des valeurs

// 2ème exercice : Variable

/*#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char *argv[])
{
  int age = 0;
  printf("quel est votre age ? ");
  scanf("%d", &age);
  printf("Vous avez %d ans \n", age);
       
  return 0;
}
*/

// 4ème exercices : Calcul 

/*#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char *argv[])
{
  int age = 0, annee = 0 , result = 0;
  const int ACTUAL_YEAR = 2024 ;
  printf("quel est votre age ? ");
  scanf("%d", &age);
  printf("Dans quelle année voulez vous savoir votre age ? ");
  scanf("%d", &annee);
  result = age + annee - ACTUAL_YEAR;
  printf("Vous aurez %d ans en %d \n", result, annee);
  return 0;
}
*/

// 5ème  exercice : conditions

/*#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char *argv[])
{
  int choix = 0 ;
  printf("Quel restaurant voulez vous choisir ? \n 1. MacDonald \n 2. KFC \n 3. Burguer King ");
  scanf("%d", &choix);
  
  switch (choix){
    case 1: 
      printf("Nous irons donc au MacDonalds");
      break;
    case 2:
      printf("Nous irons au KFC");
      break;
    case 3:
      printf("Nous irons au BK");
      break;
    default :
      printf("ceci n'ai pas une option");
      break;
  }

  return 0;
}
*/

// 6ème exercice : boucle
/*
#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char *argv[])
{
  int compteur = 0;
  while (compteur < 5)
  {
    compteur++;
    printf("%d", compteur);
  }
  return 0;
}
*/

// 7ème exercice : fonctions
/*
#include <stdio.h>
#include <stdlib.h>
 
int multiplication(int a, int b){
  return a*b;
}

int main(int argc, char *argv[])
{
  int a = 0, b = 0 ;
  printf("quels nombres voulez vous multiplier \n");
  scanf("%d", &a );
  scanf("%d", &b );
  int result = multiplication(a,b);
  printf("%d",result);

  return 0;
}
*/
// 8ème exercice : utilisations de fichier multiples

/*
#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"

int main(int argc, char *argv[])
{
  int a = 0, b = 0 ;
  printf("quels nombres voulez vous multiplier \n");
  scanf("%d", &a );
  scanf("%d", &b );
  int result = multiplication(a,b);
  printf("%d",result);

  return 0;
}
*/

// 10ème exercice : tableau

/*
#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"

int main(int argc, char *argv[]){
    int tableau[]= {1, 2, 3, 2};
    int taille = 4;
    int affiche= sommeTab(tableau, taille);
    printf("%d", affiche);

    return 0 ;
}
*/


