#ifndef FONCTION_H
#define FONCTION_H
#include <stdio.h>

int multiplication(int a, int b);
int sommeTab(int tableau[], int taille);

#endif