#include <stdio.h>
#include <string.h>
#include "fonction.h"

int multiplication(int a, int b){
    return a * b ;
}

int sommeTab(int tableau[], int taille){
    int result = 0;
    for( int i=0 ; i < taille ; i++ )
    {
        result += tableau[i] ;
    }
    return result;
}